// Spot the phish: three questions, then a score. Reports to an LMS through the
// SCORM 1.2 API when one is present (window.API on a parent frame); works the
// same without one.
(function () {
  var QUESTIONS = [
    { from: 'IT Service Desk <it-support@micros0ft-help.com>', subject: 'Your mailbox is full - verify now or lose email', phish: true,
      why: 'Look-alike sender domain (micros0ft) and pressure to act now.' },
    { from: 'Payroll <payroll@yourcompany.com>', subject: 'Your October payslip is available in the HR portal', phish: false,
      why: 'Expected message from a known sender, pointing you to the usual portal.' },
    { from: 'CEO <ceo.office@gmail.com>', subject: 'Urgent: buy gift cards for a client, keep this quiet', phish: true,
      why: 'Executive name on a personal address, urgency and secrecy.' }
  ];

  function findAPI(win) {
    for (var i = 0; win && i < 10; i += 1) {
      if (win.API) return win.API;
      if (win.parent === win) break;
      win = win.parent;
    }
    return null;
  }
  var api = null;
  try { api = findAPI(window); } catch (e) { api = null; }
  if (api) { api.LMSInitialize(''); api.LMSSetValue('cmi.core.lesson_status', 'incomplete'); }

  var list = document.getElementById('questions');
  var finish = document.getElementById('finish');
  var result = document.getElementById('result');
  var answers = {};

  QUESTIONS.forEach(function (q, i) {
    var li = document.createElement('li');
    li.innerHTML = '<div class="mail"><b></b><span></span></div>' +
      '<label><input type="radio" name="q' + i + '" value="yes"> Phishing</label>' +
      '<label><input type="radio" name="q' + i + '" value="no"> Genuine</label>' +
      '<span class="why" hidden></span>';
    li.querySelector('b').textContent = q.from;
    li.querySelector('span').textContent = q.subject;
    li.querySelector('.why').textContent = q.why;
    li.addEventListener('change', function (e) {
      answers[i] = e.target.value === 'yes';
      finish.disabled = Object.keys(answers).length < QUESTIONS.length;
    });
    list.appendChild(li);
  });

  finish.addEventListener('click', function () {
    var right = 0;
    QUESTIONS.forEach(function (q, i) {
      if (answers[i] === q.phish) right += 1;
      list.children[i].querySelector('.why').hidden = false;
    });
    var score = Math.round((right / QUESTIONS.length) * 100);
    result.textContent = 'You got ' + right + ' of ' + QUESTIONS.length + ' right (' + score + '%).';
    if (api) {
      api.LMSSetValue('cmi.core.score.raw', String(score));
      api.LMSSetValue('cmi.core.lesson_status', score >= 67 ? 'passed' : 'failed');
      api.LMSCommit('');
      api.LMSFinish('');
    }
    finish.disabled = true;
  });
})();
